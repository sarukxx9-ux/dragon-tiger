package com.example

import com.example.domain.CardShoe
import com.example.domain.DragonTigerRules
import com.example.domain.PickSide
import com.example.domain.PlayingCard
import com.example.domain.Rank
import com.example.domain.RoundOutcome
import com.example.domain.Suit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun dragonWin_paysOneToOne() {
        val result = DragonTigerRules.settleHand(
            dragonCard = PlayingCard(Rank.KING, Suit.SPADES),
            tigerCard = PlayingCard(Rank.SEVEN, Suit.HEARTS),
            pickedSide = PickSide.DRAGON,
            stakeCoins = 500L,
        )
        assertEquals(PickSide.DRAGON, result.winningSide)
        assertEquals(RoundOutcome.WIN, result.outcome)
        assertEquals(1_000L, result.payoutCoins)
        assertEquals(500L, result.netCoins)
    }

    @Test
    fun tigerWin_againstDragonPick_losesStake() {
        val result = DragonTigerRules.settleHand(
            dragonCard = PlayingCard(Rank.ACE, Suit.CLUBS),
            tigerCard = PlayingCard(Rank.TWO, Suit.DIAMONDS),
            pickedSide = PickSide.DRAGON,
            stakeCoins = 100L,
        )
        assertEquals(PickSide.TIGER, result.winningSide)
        assertEquals(RoundOutcome.LOSS, result.outcome)
        assertEquals(0L, result.payoutCoins)
        assertEquals(-100L, result.netCoins)
    }

    @Test
    fun tieWin_paysEightToOne() {
        val result = DragonTigerRules.settleHand(
            dragonCard = PlayingCard(Rank.QUEEN, Suit.HEARTS),
            tigerCard = PlayingCard(Rank.QUEEN, Suit.SPADES),
            pickedSide = PickSide.TIE,
            stakeCoins = 100L,
        )
        assertEquals(PickSide.TIE, result.winningSide)
        assertEquals(RoundOutcome.WIN, result.outcome)
        assertEquals(900L, result.payoutCoins)
        assertEquals(800L, result.netCoins)
    }

    @Test
    fun tieOutcome_onDragonPick_returnsHalfStake() {
        val result = DragonTigerRules.settleHand(
            dragonCard = PlayingCard(Rank.TEN, Suit.DIAMONDS),
            tigerCard = PlayingCard(Rank.TEN, Suit.CLUBS),
            pickedSide = PickSide.DRAGON,
            stakeCoins = 200L,
        )
        assertEquals(PickSide.TIE, result.winningSide)
        assertEquals(RoundOutcome.HALF_BACK, result.outcome)
        assertEquals(100L, result.payoutCoins)
        assertEquals(-100L, result.netCoins)
    }

    @Test
    fun cardShoe_replenishesAutomatically() {
        val shoe = CardShoe(deckCount = 1)
        assertEquals(52, shoe.remainingCards)
        repeat(20) { shoe.drawPair() }
        assertTrue(shoe.remainingCards > 0)
    }
}
