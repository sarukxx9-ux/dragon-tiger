package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.DragonTigerDatabase
import com.example.data.DragonTigerRepository
import com.example.ui.DragonTigerApp
import com.example.ui.DragonTigerViewModel
import com.example.ui.theme.DragonTigerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )

        val database = DragonTigerDatabase.getInstance(applicationContext)
        val repository = DragonTigerRepository(database.dragonTigerDao())

        setContent {
            DragonTigerTheme {
                val dragonTigerViewModel: DragonTigerViewModel = viewModel(
                    factory = DragonTigerViewModel.factory(repository),
                )
                DragonTigerApp(viewModel = dragonTigerViewModel)
            }
        }
    }
}
