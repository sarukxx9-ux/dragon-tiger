package com.example.ui

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.ui.components.RulesModalSheet
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.TableScreen
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldBright
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MidnightNavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceHigh
import com.example.ui.theme.SlateMist

const val ROUTE_TABLE = "table"
const val ROUTE_HISTORY = "history"
const val ROUTE_PROFILE = "profile"

private data class NavDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
)

private val TopDestinations = listOf(
    NavDestination(
        route = ROUTE_TABLE,
        labelRes = R.string.nav_table,
        selectedIcon = Icons.Filled.Style,
        unselectedIcon = Icons.Outlined.Style,
        testTag = "nav_table",
    ),
    NavDestination(
        route = ROUTE_HISTORY,
        labelRes = R.string.nav_history,
        selectedIcon = Icons.Filled.History,
        unselectedIcon = Icons.Outlined.History,
        testTag = "nav_history",
    ),
    NavDestination(
        route = ROUTE_PROFILE,
        labelRes = R.string.nav_profile,
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.Person,
        testTag = "nav_profile",
    ),
)

@Composable
fun DragonTigerApp(
    viewModel: DragonTigerViewModel,
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_TABLE
    var showRulesSheet by remember { mutableStateOf(false) }

    fun navigateTo(route: String) {
        if (currentRoute == route) return
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MidnightNavy,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar(
                        containerColor = NavySurface,
                        contentColor = ImperialGoldBright,
                    ) {
                        TopDestinations.forEach { destination ->
                            val selected = currentRoute == destination.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(destination.route) },
                                modifier = Modifier.testTag(destination.testTag),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                                        contentDescription = stringResource(destination.labelRes),
                                    )
                                },
                                label = { Text(stringResource(destination.labelRes)) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ImperialGoldBright,
                                    selectedTextColor = ImperialGoldBright,
                                    indicatorColor = NavySurfaceHigh,
                                    unselectedIconColor = SlateMist,
                                    unselectedTextColor = SlateMist,
                                ),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (useNavRail) {
                    NavigationRail(
                        modifier = Modifier.fillMaxHeight(),
                        containerColor = MidnightNavyDeep,
                        contentColor = ImperialGoldBright,
                    ) {
                        TopDestinations.forEach { destination ->
                            val selected = currentRoute == destination.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(destination.route) },
                                modifier = Modifier.testTag(destination.testTag),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                                        contentDescription = stringResource(destination.labelRes),
                                    )
                                },
                                label = { Text(stringResource(destination.labelRes)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = ImperialGoldBright,
                                    selectedTextColor = ImperialGoldBright,
                                    indicatorColor = NavySurfaceHigh,
                                    unselectedIconColor = SlateMist,
                                    unselectedTextColor = SlateMist,
                                ),
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ROUTE_TABLE,
                    modifier = Modifier.weight(1f),
                ) {
                    composable(ROUTE_TABLE) {
                        TableScreen(
                            uiState = uiState,
                            onSelectSide = viewModel::selectSide,
                            onAddChip = viewModel::addChip,
                            onClearStake = viewModel::clearStake,
                            onDoubleStake = viewModel::doubleStake,
                            onHalveStake = viewModel::halveStake,
                            onRebet = viewModel::rebet,
                            onDeal = viewModel::dealHand,
                            onClaimRefill = viewModel::claimDemoRefill,
                            onOpenRules = { showRulesSheet = true },
                        )
                    }
                    composable(ROUTE_HISTORY) {
                        HistoryScreen(
                            rounds = uiState.recentRounds,
                            onClearHistory = viewModel::clearHistory,
                        )
                    }
                    composable(ROUTE_PROFILE) {
                        ProfileScreen(
                            profile = uiState.profile,
                            onUpdateName = viewModel::updateDisplayName,
                            onUpdateAvatar = viewModel::updateAvatar,
                            onClaimRefill = viewModel::claimDemoRefill,
                            onToggleHaptics = viewModel::setHapticsEnabled,
                            onResetDemo = viewModel::resetDemoAccount,
                        )
                    }
                }
            }
        }
    }

    if (showRulesSheet) {
        RulesModalSheet(onDismiss = { showRulesSheet = false })
    }
}
