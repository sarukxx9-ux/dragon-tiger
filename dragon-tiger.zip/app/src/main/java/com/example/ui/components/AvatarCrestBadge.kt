package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.AvatarCrest
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldBright
import com.example.ui.theme.MidnightNavyDeep
import com.example.ui.theme.NavySurfaceHigh

@Composable
fun AvatarCrestBadge(
    crest: AvatarCrest,
    size: Dp = 64.dp,
    isSelected: Boolean = true,
    modifier: Modifier = Modifier,
) {
    val borderBrush = if (isSelected) {
        Brush.linearGradient(listOf(ImperialGoldBright, ImperialGold, ImperialGoldBright))
    } else {
        Brush.linearGradient(listOf(ImperialGold.copy(alpha = 0.35f), ImperialGold.copy(alpha = 0.2f)))
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(listOf(NavySurfaceHigh, MidnightNavyDeep))
            )
            .border(
                width = if (isSelected) 2.5.dp else 1.dp,
                brush = borderBrush,
                shape = CircleShape,
            ),
        contentAlignment = Alignment.Center,
    ) {
        when (crest) {
            AvatarCrest.DRAGON_GUARDIAN -> Image(
                painter = painterResource(id = R.drawable.img_dragon_art),
                contentDescription = crest.title,
                modifier = Modifier.fillMaxSize().clip(CircleShape),
                contentScale = ContentScale.Crop,
            )
            AvatarCrest.TIGER_SOVEREIGN -> Image(
                painter = painterResource(id = R.drawable.img_tiger_art),
                contentDescription = crest.title,
                modifier = Modifier.fillMaxSize().clip(CircleShape),
                contentScale = ContentScale.Crop,
            )
            AvatarCrest.IMPERIAL_LOTUS -> Image(
                painter = painterResource(id = R.drawable.img_card_back),
                contentDescription = crest.title,
                modifier = Modifier.fillMaxSize().clip(CircleShape),
                contentScale = ContentScale.Crop,
            )
            AvatarCrest.CROWN_MASTER -> Icon(
                imageVector = Icons.Filled.WorkspacePremium,
                contentDescription = crest.title,
                tint = ImperialGoldBright,
                modifier = Modifier.size(size * 0.56f),
            )
        }
    }
}
