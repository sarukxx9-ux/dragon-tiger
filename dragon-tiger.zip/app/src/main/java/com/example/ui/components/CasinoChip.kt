package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldBright
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightNavyDeep

@Composable
fun CasinoChipButton(
    denomination: Long,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed) 0.90f else 1f,
        animationSpec = spring(),
        label = "chip_press_scale",
    )

    val (outerColor, innerColor, textColor) = when (denomination) {
        25L -> Triple(Color(0xFFB8293A), Color(0xFF7D1624), IvoryWhite)
        100L -> Triple(Color(0xFF2155A8), Color(0xFF13346D), IvoryWhite)
        500L -> Triple(Color(0xFF1B8A66), Color(0xFF105740), IvoryWhite)
        1_000L -> Triple(Color(0xFF723BA8), Color(0xFF472070), IvoryWhite)
        else -> Triple(ImperialGold, Color(0xFFA8791B), MidnightNavyDeep)
    }

    val label = when {
        denomination >= 1_000L -> "${denomination / 1_000L}K"
        else -> denomination.toString()
    }

    Box(
        modifier = modifier
            .defaultMinSize(minWidth = 52.dp, minHeight = 52.dp)
            .size(54.dp)
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
            }
            .alpha(if (enabled) 1f else 0.36f)
            .clip(CircleShape)
            .testTag("chip_$denomination")
            .semantics {
                contentDescription = "Add $denomination virtual demo coins"
            }
            .clickable(
                enabled = enabled,
                role = Role.Button,
                interactionSource = interactionSource,
                indication = ripple(bounded = true, color = ImperialGoldBright),
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val radius = size.minDimension / 2f
            // Base chip body
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(outerColor, innerColor),
                ),
                radius = radius,
            )
            // Dashed edge inlays
            drawCircle(
                color = ImperialGoldBright.copy(alpha = 0.85f),
                radius = radius - 3.dp.toPx(),
                style = Stroke(
                    width = 3.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f), 0f),
                ),
            )
            // Metallic inner gold ring
            drawCircle(
                color = ImperialGold.copy(alpha = 0.9f),
                radius = radius - 8.dp.toPx(),
                style = Stroke(width = 1.5.dp.toPx()),
            )
            // Outer rim stroke
            drawCircle(
                color = ImperialGoldBright.copy(alpha = 0.45f),
                radius = radius - 1.dp.toPx(),
                style = Stroke(width = 1.dp.toPx()),
            )
        }
        Text(
            text = label,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = if (label.length >= 3) 12.sp else 13.sp,
            color = textColor,
        )
    }
}
