package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.PlayerProfileEntity
import com.example.domain.AvatarCrest
import com.example.ui.components.AvatarCrestBadge
import com.example.ui.components.formatDemoCoins
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.DragonCrimson
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldBright
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MidnightNavyDeep
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavySurfaceHigh
import com.example.ui.theme.SlateMist
import com.example.ui.theme.TieEmerald

@Composable
fun ProfileScreen(
    profile: PlayerProfileEntity,
    onUpdateName: (String) -> Unit,
    onUpdateAvatar: (Int) -> Unit,
    onClaimRefill: () -> Unit,
    onToggleHaptics: (Boolean) -> Unit,
    onResetDemo: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var showEditNameDialog by remember { mutableStateOf(false) }
    var showResetConfirm by remember { mutableStateOf(false) }

    val selectedCrest = AvatarCrest.fromId(profile.avatarId)
    val winRate = if (profile.totalRounds > 0) {
        (profile.totalWins * 100) / profile.totalRounds
    } else {
        0
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(MidnightNavyDeep, MidnightNavy, MidnightNavyDeep))
            ),
    ) {
        BoxWithConstraints(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter,
        ) {
            val isWide = maxWidth >= 600.dp

            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = if (isWide) 24.dp else 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    text = stringResource(R.string.profile_title),
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontFamily = CinzelFontFamily,
                    ),
                    color = ImperialGoldBright,
                )

                // Player Identity Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = NavySurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, ImperialGold.copy(alpha = 0.55f)),
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                            ) {
                                AvatarCrestBadge(
                                    crest = selectedCrest,
                                    size = 68.dp,
                                    isSelected = true,
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = profile.displayName,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = IvoryWhite,
                                    )
                                    Text(
                                        text = "${selectedCrest.title} • ${selectedCrest.subtitle}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = ImperialGold,
                                    )
                                }
                            }

                            Surface(
                                color = NavySurfaceElevated,
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, NavyBorder),
                            ) {
                                IconButton(
                                    onClick = { showEditNameDialog = true },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("edit_profile_name_button"),
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Edit,
                                        contentDescription = stringResource(R.string.cd_edit_profile_name),
                                        tint = ImperialGoldBright,
                                    )
                                }
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = stringResource(R.string.profile_choose_emblem),
                                style = MaterialTheme.typography.labelSmall,
                                color = SlateMist,
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                AvatarCrest.entries.forEach { crest ->
                                    val isCurrent = crest.id == profile.avatarId
                                    Column(
                                        modifier = Modifier
                                            .defaultMinSize(minWidth = 64.dp, minHeight = 64.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .clickable { onUpdateAvatar(crest.id) }
                                            .padding(4.dp)
                                            .testTag("avatar_option_${crest.id}"),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(4.dp),
                                    ) {
                                        AvatarCrestBadge(
                                            crest = crest,
                                            size = 52.dp,
                                            isSelected = isCurrent,
                                        )
                                        Text(
                                            text = crest.title.split(" ").last(),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (isCurrent) ImperialGoldBright else SlateMist,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Virtual Demo Wallet Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = NavySurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column {
                                Text(
                                    text = stringResource(R.string.profile_wallet_title),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = ImperialGold,
                                )
                                Text(
                                    text = formatDemoCoins(profile.demoCoins),
                                    style = MaterialTheme.typography.displaySmall.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.Bold,
                                    ),
                                    color = IvoryWhite,
                                )
                            }
                            Icon(
                                imageVector = Icons.Filled.MonetizationOn,
                                contentDescription = null,
                                tint = ImperialGoldBright,
                                modifier = Modifier.size(36.dp),
                            )
                        }

                        Button(
                            onClick = onClaimRefill,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("profile_claim_refill_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ImperialGold,
                                contentColor = MidnightNavyDeep,
                            ),
                            shape = RoundedCornerShape(14.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.action_claim_coins),
                                style = MaterialTheme.typography.labelLarge,
                            )
                        }

                        Surface(
                            color = NavySurfaceElevated,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, TieEmerald.copy(alpha = 0.4f)),
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Shield,
                                    contentDescription = null,
                                    tint = TieEmerald,
                                    modifier = Modifier.size(20.dp),
                                )
                                Text(
                                    text = stringResource(R.string.demo_disclaimer_full),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SlateMist,
                                )
                            }
                        }
                    }
                }

                // Performance Statistics Grid
                Text(
                    text = stringResource(R.string.profile_stats_title),
                    style = MaterialTheme.typography.titleSmall,
                    color = ImperialGold,
                )

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        StatMetricCard(
                            label = "Hands Played",
                            value = profile.totalRounds.toString(),
                            modifier = Modifier.weight(1f),
                        )
                        StatMetricCard(
                            label = "Win Rate",
                            value = "$winRate%",
                            modifier = Modifier.weight(1f),
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        StatMetricCard(
                            label = "Current Streak",
                            value = profile.currentStreak.toString(),
                            modifier = Modifier.weight(1f),
                        )
                        StatMetricCard(
                            label = "Best Streak",
                            value = profile.bestStreak.toString(),
                            modifier = Modifier.weight(1f),
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        StatMetricCard(
                            label = "Biggest Win",
                            value = formatDemoCoins(profile.biggestWin),
                            modifier = Modifier.weight(1f),
                        )
                        StatMetricCard(
                            label = "Ties Hit (8:1)",
                            value = profile.totalTiesHit.toString(),
                            modifier = Modifier.weight(1f),
                        )
                    }
                }

                // Preferences & Reset
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = NavySurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, NavyBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.profile_haptics_label),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = IvoryWhite,
                                )
                                Text(
                                    text = stringResource(R.string.profile_haptics_subtitle),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SlateMist,
                                )
                            }
                            Switch(
                                checked = profile.hapticsEnabled,
                                onCheckedChange = onToggleHaptics,
                                modifier = Modifier.testTag("haptics_switch"),
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = MidnightNavyDeep,
                                    checkedTrackColor = ImperialGold,
                                    uncheckedThumbColor = SlateMist,
                                    uncheckedTrackColor = NavySurfaceHigh,
                                ),
                            )
                        }

                        OutlinedButton(
                            onClick = { showResetConfirm = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("reset_demo_button"),
                            border = BorderStroke(1.dp, DragonCrimson.copy(alpha = 0.7f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = DragonCrimson),
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.RestartAlt,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.profile_reset_demo),
                                style = MaterialTheme.typography.labelLarge,
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }

    if (showEditNameDialog) {
        var draftName by remember(profile.displayName) { mutableStateOf(profile.displayName) }
        AlertDialog(
            onDismissRequest = { showEditNameDialog = false },
            containerColor = NavySurface,
            titleContentColor = ImperialGoldBright,
            textContentColor = IvoryWhite,
            title = { Text(stringResource(R.string.profile_edit_name)) },
            text = {
                OutlinedTextField(
                    value = draftName,
                    onValueChange = { if (it.length <= 22) draftName = it },
                    label = { Text(stringResource(R.string.profile_name_label)) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ImperialGold,
                        unfocusedBorderColor = NavyBorder,
                        focusedTextColor = IvoryWhite,
                        unfocusedTextColor = IvoryWhite,
                        focusedLabelColor = ImperialGoldBright,
                        unfocusedLabelColor = SlateMist,
                    ),
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onUpdateName(draftName)
                        showEditNameDialog = false
                    },
                    enabled = draftName.trim().isNotEmpty(),
                    colors = ButtonDefaults.textButtonColors(contentColor = ImperialGoldBright),
                    modifier = Modifier.testTag("save_profile_name_button"),
                ) {
                    Text(stringResource(R.string.action_save))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showEditNameDialog = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = SlateMist),
                ) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            containerColor = NavySurface,
            titleContentColor = ImperialGoldBright,
            textContentColor = IvoryWhite,
            title = { Text(stringResource(R.string.profile_reset_confirm_title)) },
            text = { Text(stringResource(R.string.profile_reset_confirm_body)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showResetConfirm = false
                        onResetDemo()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = DragonCrimson),
                    modifier = Modifier.testTag("confirm_reset_demo_button"),
                ) {
                    Text(stringResource(R.string.action_confirm))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showResetConfirm = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = SlateMist),
                ) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }
}

@Composable
private fun StatMetricCard(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = NavySurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, NavyBorder),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = SlateMist,
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = JetBrainsMonoFontFamily,
                ),
                color = ImperialGoldBright,
            )
        }
    }
}
