package com.example.ui.components

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatDemoCoins(amount: Long): String {
    return NumberFormat.getNumberInstance(Locale.US).format(amount)
}

fun formatSignedDemoCoins(amount: Long): String {
    val formatted = NumberFormat.getNumberInstance(Locale.US).format(kotlin.math.abs(amount))
    return when {
        amount > 0L -> "+$formatted"
        amount < 0L -> "-$formatted"
        else -> "0"
    }
}

fun formatRoundTime(timestampMillis: Long): String {
    val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    return formatter.format(Date(timestampMillis))
}
