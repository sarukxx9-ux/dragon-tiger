package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.DragonTigerRepository
import com.example.data.PlayerProfileEntity
import com.example.data.RoundHistoryEntity
import com.example.domain.CardShoe
import com.example.domain.DragonTigerRules
import com.example.domain.PickSide
import com.example.domain.PlayingCard
import com.example.domain.RoundSettlement
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class DealPhase {
    IDLE,
    DEALING_DRAGON,
    DEALING_TIGER,
    REVEALED,
}

data class TableUiState(
    val profile: PlayerProfileEntity = PlayerProfileEntity(),
    val recentRounds: List<RoundHistoryEntity> = emptyList(),
    val selectedSide: PickSide = PickSide.DRAGON,
    val stakeCoins: Long = 100L,
    val lastStakeCoins: Long = 100L,
    val dealPhase: DealPhase = DealPhase.IDLE,
    val dragonCard: PlayingCard? = null,
    val tigerCard: PlayingCard? = null,
    val isDragonRevealed: Boolean = false,
    val isTigerRevealed: Boolean = false,
    val lastSettlement: RoundSettlement? = null,
    val shoeRemaining: Int = 312,
    val bannerMessage: String? = null,
) {
    val isDealing: Boolean
        get() = dealPhase == DealPhase.DEALING_DRAGON || dealPhase == DealPhase.DEALING_TIGER

    val canDeal: Boolean
        get() = !isDealing && stakeCoins > 0L && stakeCoins <= profile.demoCoins

    val needsRefill: Boolean
        get() = profile.demoCoins < DragonTigerRules.MIN_CHIP_DENOMINATION
}

private data class TransientTableState(
    val selectedSide: PickSide = PickSide.DRAGON,
    val stakeCoins: Long = 100L,
    val lastStakeCoins: Long = 100L,
    val dealPhase: DealPhase = DealPhase.IDLE,
    val dragonCard: PlayingCard? = null,
    val tigerCard: PlayingCard? = null,
    val isDragonRevealed: Boolean = false,
    val isTigerRevealed: Boolean = false,
    val lastSettlement: RoundSettlement? = null,
    val shoeRemaining: Int = 312,
    val bannerMessage: String? = null,
)

class DragonTigerViewModel(
    private val repository: DragonTigerRepository,
) : ViewModel() {

    private val shoe = CardShoe(deckCount = 6)
    private val transientState = MutableStateFlow(
        TransientTableState(shoeRemaining = shoe.remainingCards)
    )
    private var dealJob: Job? = null

    val uiState: StateFlow<TableUiState> = combine(
        repository.profileFlow,
        repository.recentRoundsFlow,
        transientState,
    ) { profile, rounds, transient ->
        val adjustedStake = if (transient.dealPhase == DealPhase.IDLE && transient.stakeCoins > profile.demoCoins) {
            profile.demoCoins.coerceAtLeast(0L)
        } else {
            transient.stakeCoins
        }
        TableUiState(
            profile = profile,
            recentRounds = rounds,
            selectedSide = transient.selectedSide,
            stakeCoins = adjustedStake,
            lastStakeCoins = transient.lastStakeCoins,
            dealPhase = transient.dealPhase,
            dragonCard = transient.dragonCard,
            tigerCard = transient.tigerCard,
            isDragonRevealed = transient.isDragonRevealed,
            isTigerRevealed = transient.isTigerRevealed,
            lastSettlement = transient.lastSettlement,
            shoeRemaining = transient.shoeRemaining,
            bannerMessage = transient.bannerMessage,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = TableUiState(),
    )

    init {
        viewModelScope.launch {
            repository.ensureInitialized()
        }
    }

    fun selectSide(side: PickSide) {
        if (uiState.value.isDealing) return
        transientState.update { current ->
            val resetToIdle = current.dealPhase == DealPhase.REVEALED
            current.copy(
                selectedSide = side,
                dealPhase = if (resetToIdle) DealPhase.IDLE else current.dealPhase,
                isDragonRevealed = if (resetToIdle) false else current.isDragonRevealed,
                isTigerRevealed = if (resetToIdle) false else current.isTigerRevealed,
                lastSettlement = if (resetToIdle) null else current.lastSettlement,
                bannerMessage = null,
            )
        }
    }

    fun addChip(amount: Long) {
        val currentUi = uiState.value
        if (currentUi.isDealing) return
        val available = currentUi.profile.demoCoins
        if (available < DragonTigerRules.MIN_CHIP_DENOMINATION) {
            transientState.update { it.copy(bannerMessage = "Low demo coins — claim a free +5,000 refill!") }
            return
        }
        transientState.update { current ->
            val baseStake = if (current.dealPhase == DealPhase.REVEALED) 0L else current.stakeCoins
            val nextStake = (baseStake + amount).coerceAtMost(available)
            current.copy(
                stakeCoins = nextStake,
                dealPhase = DealPhase.IDLE,
                isDragonRevealed = false,
                isTigerRevealed = false,
                lastSettlement = null,
                bannerMessage = null,
            )
        }
    }

    fun clearStake() {
        if (uiState.value.isDealing) return
        transientState.update {
            it.copy(
                stakeCoins = 0L,
                dealPhase = DealPhase.IDLE,
                isDragonRevealed = false,
                isTigerRevealed = false,
                lastSettlement = null,
                bannerMessage = null,
            )
        }
    }

    fun doubleStake() {
        val currentUi = uiState.value
        if (currentUi.isDealing) return
        val available = currentUi.profile.demoCoins
        if (available <= 0L) return
        transientState.update { current ->
            val base = if (current.stakeCoins <= 0L) DragonTigerRules.MIN_CHIP_DENOMINATION else current.stakeCoins * 2L
            current.copy(
                stakeCoins = base.coerceAtMost(available),
                dealPhase = DealPhase.IDLE,
                isDragonRevealed = false,
                isTigerRevealed = false,
                lastSettlement = null,
                bannerMessage = null,
            )
        }
    }

    fun halveStake() {
        val currentUi = uiState.value
        if (currentUi.isDealing) return
        transientState.update { current ->
            val halved = (current.stakeCoins / 2L).coerceAtLeast(
                if (currentUi.profile.demoCoins >= DragonTigerRules.MIN_CHIP_DENOMINATION) {
                    DragonTigerRules.MIN_CHIP_DENOMINATION
                } else {
                    0L
                }
            )
            current.copy(
                stakeCoins = halved.coerceAtMost(currentUi.profile.demoCoins),
                dealPhase = DealPhase.IDLE,
                isDragonRevealed = false,
                isTigerRevealed = false,
                lastSettlement = null,
                bannerMessage = null,
            )
        }
    }

    fun rebet() {
        val currentUi = uiState.value
        if (currentUi.isDealing) return
        val target = currentUi.lastStakeCoins.coerceAtMost(currentUi.profile.demoCoins)
        transientState.update {
            it.copy(
                stakeCoins = target,
                dealPhase = DealPhase.IDLE,
                isDragonRevealed = false,
                isTigerRevealed = false,
                lastSettlement = null,
                bannerMessage = null,
            )
        }
    }

    fun dealHand() {
        val snapshot = uiState.value
        if (snapshot.isDealing) return
        if (snapshot.profile.demoCoins < DragonTigerRules.MIN_CHIP_DENOMINATION) {
            transientState.update { it.copy(bannerMessage = "Claim a free +5,000 Demo Coins refill to play!") }
            return
        }
        val stake = snapshot.stakeCoins
        if (stake <= 0L || stake > snapshot.profile.demoCoins) {
            transientState.update { it.copy(bannerMessage = "Select a valid demo stake up to your balance.") }
            return
        }

        val pickedSide = snapshot.selectedSide
        val (dragonCard, tigerCard) = shoe.drawPair()
        val settlement = DragonTigerRules.settleHand(
            dragonCard = dragonCard,
            tigerCard = tigerCard,
            pickedSide = pickedSide,
            stakeCoins = stake,
        )

        dealJob?.cancel()
        dealJob = viewModelScope.launch {
            transientState.update {
                it.copy(
                    dealPhase = DealPhase.DEALING_DRAGON,
                    lastStakeCoins = stake,
                    dragonCard = dragonCard,
                    tigerCard = tigerCard,
                    isDragonRevealed = false,
                    isTigerRevealed = false,
                    lastSettlement = null,
                    shoeRemaining = shoe.remainingCards,
                    bannerMessage = null,
                )
            }
            delay(180L)
            transientState.update { it.copy(isDragonRevealed = true) }
            delay(460L)
            transientState.update {
                it.copy(
                    dealPhase = DealPhase.DEALING_TIGER,
                    isTigerRevealed = true,
                )
            }
            delay(480L)
            repository.recordRound(settlement)
            transientState.update {
                it.copy(
                    dealPhase = DealPhase.REVEALED,
                    lastSettlement = settlement,
                )
            }
        }
    }

    fun claimDemoRefill() {
        viewModelScope.launch {
            repository.claimDemoRefill()
            transientState.update { current ->
                val updatedStake = if (current.stakeCoins == 0L) 100L else current.stakeCoins
                current.copy(
                    stakeCoins = updatedStake,
                    bannerMessage = "+5,000 Virtual Demo Coins added!",
                )
            }
        }
    }

    fun dismissBanner() {
        transientState.update { it.copy(bannerMessage = null) }
    }

    fun updateDisplayName(name: String) {
        viewModelScope.launch {
            repository.updateDisplayName(name)
            transientState.update { it.copy(bannerMessage = "Player name updated") }
        }
    }

    fun updateAvatar(avatarId: Int) {
        viewModelScope.launch {
            repository.updateAvatar(avatarId)
        }
    }

    fun setHapticsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setHapticsEnabled(enabled)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            transientState.update { it.copy(bannerMessage = "Round history cleared") }
        }
    }

    fun resetDemoAccount() {
        if (uiState.value.isDealing) return
        viewModelScope.launch {
            shoe.reshuffle()
            repository.resetDemoAccount()
            transientState.update {
                TransientTableState(
                    stakeCoins = 100L,
                    lastStakeCoins = 100L,
                    shoeRemaining = shoe.remainingCards,
                    bannerMessage = "Demo account reset to 10,000 coins",
                )
            }
        }
    }

    companion object {
        fun factory(repository: DragonTigerRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return DragonTigerViewModel(repository) as T
                }
            }
    }
}
