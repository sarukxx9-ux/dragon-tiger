package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.RoundHistoryEntity
import com.example.domain.PickSide
import com.example.domain.Rank
import com.example.domain.Suit
import com.example.ui.components.BeadDot
import com.example.ui.components.formatDemoCoins
import com.example.ui.components.formatRoundTime
import com.example.ui.components.formatSignedDemoCoins
import com.example.ui.theme.CardInkRed
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.DragonCrimson
import com.example.ui.theme.DragonCrimsonSurface
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldBright
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MidnightNavyDeep
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.SlateMist
import com.example.ui.theme.TieEmerald
import com.example.ui.theme.TieEmeraldSurface
import com.example.ui.theme.TigerAmber

@Composable
fun HistoryScreen(
    rounds: List<RoundHistoryEntity>,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var showClearConfirm by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(MidnightNavyDeep, MidnightNavy, MidnightNavyDeep))
            ),
    ) {
        BoxWithConstraints(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter,
        ) {
            val isWide = maxWidth >= 600.dp

            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
                    .padding(horizontal = if (isWide) 24.dp else 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.history_title),
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontFamily = CinzelFontFamily,
                            ),
                            color = ImperialGoldBright,
                        )
                        Text(
                            text = "${rounds.size} recorded hands",
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateMist,
                        )
                    }

                    if (rounds.isNotEmpty()) {
                        Surface(
                            color = NavySurfaceElevated,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, NavyBorder),
                        ) {
                            IconButton(
                                onClick = { showClearConfirm = true },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("clear_history_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteOutline,
                                    contentDescription = stringResource(R.string.history_clear),
                                    tint = DragonCrimson,
                                )
                            }
                        }
                    }
                }

                if (rounds.isEmpty()) {
                    EmptyHistoryState(modifier = Modifier.weight(1f))
                } else {
                    HistorySummaryStrip(rounds = rounds)

                    BeadGridCard(rounds = rounds)

                    Text(
                        text = stringResource(R.string.recent_hands_title),
                        style = MaterialTheme.typography.titleSmall,
                        color = ImperialGold,
                    )

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentPadding = PaddingValues(bottom = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(rounds, key = { it.id }) { round ->
                            RoundHistoryCard(round = round)
                        }
                    }
                }
            }
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            containerColor = NavySurface,
            titleContentColor = ImperialGoldBright,
            textContentColor = IvoryWhite,
            title = { Text(stringResource(R.string.history_clear_confirm_title)) },
            text = { Text(stringResource(R.string.history_clear_confirm_body)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearConfirm = false
                        onClearHistory()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = DragonCrimson),
                    modifier = Modifier.testTag("confirm_clear_history_button"),
                ) {
                    Text(stringResource(R.string.action_confirm))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showClearConfirm = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = SlateMist),
                ) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }
}

@Composable
private fun EmptyHistoryState(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = NavySurface,
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, NavyBorder),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Surface(
                color = NavySurfaceElevated,
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, ImperialGold.copy(alpha = 0.45f)),
            ) {
                Icon(
                    imageVector = Icons.Filled.Style,
                    contentDescription = null,
                    tint = ImperialGoldBright,
                    modifier = Modifier
                        .padding(18.dp)
                        .size(42.dp),
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = stringResource(R.string.history_empty_title),
                style = MaterialTheme.typography.headlineSmall.copy(fontFamily = CinzelFontFamily),
                color = IvoryWhite,
                textAlign = TextAlign.Center,
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.history_empty_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = SlateMist,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun HistorySummaryStrip(rounds: List<RoundHistoryEntity>) {
    val total = rounds.size.coerceAtLeast(1)
    val dragonCount = rounds.count { it.winningSide == PickSide.DRAGON.name }
    val tigerCount = rounds.count { it.winningSide == PickSide.TIGER.name }
    val tieCount = rounds.count { it.winningSide == PickSide.TIE.name }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        SideStatPill(
            label = "Dragon",
            count = dragonCount,
            pct = (dragonCount * 100) / total,
            accent = DragonCrimson,
            modifier = Modifier.weight(1f),
        )
        SideStatPill(
            label = "Tie",
            count = tieCount,
            pct = (tieCount * 100) / total,
            accent = TieEmerald,
            modifier = Modifier.weight(1f),
        )
        SideStatPill(
            label = "Tiger",
            count = tigerCount,
            pct = (tigerCount * 100) / total,
            accent = TigerAmber,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun SideStatPill(
    label: String,
    count: Int,
    pct: Int,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = NavySurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = accent,
            )
            Text(
                text = "$count ($pct%)",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontFamily = JetBrainsMonoFontFamily,
                ),
                color = IvoryWhite,
            )
        }
    }
}

@Composable
private fun BeadGridCard(rounds: List<RoundHistoryEntity>) {
    val chronologicalRecent = rounds.take(36).reversed()
    val columns = chronologicalRecent.chunked(6)

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = NavySurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, NavyBorder),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = stringResource(R.string.road_map_title),
                style = MaterialTheme.typography.labelSmall,
                color = ImperialGold,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                columns.forEach { column ->
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        column.forEach { item ->
                            BeadDot(winningSide = item.winningSide, sizeDp = 24)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundHistoryCard(round: RoundHistoryEntity) {
    val dragonSuit = Suit.entries.firstOrNull { it.name == round.dragonSuit } ?: Suit.SPADES
    val tigerSuit = Suit.entries.firstOrNull { it.name == round.tigerSuit } ?: Suit.HEARTS
    val dragonRank = Rank.fromValue(round.dragonRank)
    val tigerRank = Rank.fromValue(round.tigerRank)

    val netColor = when {
        round.netCoins > 0L -> TieEmerald
        round.netCoins < 0L && round.payoutCoins > 0L -> ImperialGoldBright
        else -> DragonCrimson
    }

    val badgeBg = when {
        round.netCoins > 0L -> TieEmeraldSurface
        round.payoutCoins > 0L -> NavySurfaceElevated
        else -> DragonCrimsonSurface
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = NavySurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, NavyBorder),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                BeadDot(winningSide = round.winningSide, sizeDp = 30)
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = "#${round.roundNumber}",
                            style = MaterialTheme.typography.labelMedium,
                            color = ImperialGoldBright,
                        )
                        Text(
                            text = "•",
                            color = SlateMist,
                        )
                        CardMiniPill(
                            prefix = "D",
                            cardLabel = "${dragonRank.symbol}${dragonSuit.symbol}",
                            isRed = dragonSuit.isRed,
                        )
                        Text(
                            text = "vs",
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateMist,
                        )
                        CardMiniPill(
                            prefix = "T",
                            cardLabel = "${tigerRank.symbol}${tigerSuit.symbol}",
                            isRed = tigerSuit.isRed,
                        )
                    }
                    Text(
                        text = "Pick: ${round.pickedSide} • Stake: ${formatDemoCoins(round.stakeCoins)} • ${formatRoundTime(round.timestampMillis)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateMist,
                    )
                }
            }

            Surface(
                color = badgeBg,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, netColor.copy(alpha = 0.5f)),
            ) {
                Text(
                    text = formatSignedDemoCoins(round.netCoins),
                    style = MaterialTheme.typography.labelMedium,
                    color = netColor,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun CardMiniPill(
    prefix: String,
    cardLabel: String,
    isRed: Boolean,
) {
    Surface(
        color = NavySurfaceElevated,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, NavyBorder),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            Text(
                text = prefix,
                style = MaterialTheme.typography.labelSmall,
                color = SlateMist,
            )
            Text(
                text = cardLabel,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (isRed) CardInkRed else IvoryWhite,
            )
        }
    }
}
