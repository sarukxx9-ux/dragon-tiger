package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldBright
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MidnightNavyDeep
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.SlateMist
import com.example.ui.theme.TieEmerald

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RulesModalSheet(
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = NavySurface,
        contentColor = IvoryWhite,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 24.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = stringResource(R.string.rules_title),
                style = MaterialTheme.typography.headlineSmall,
                color = ImperialGoldBright,
            )

            Surface(
                color = NavySurfaceElevated,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, NavyBorder),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = stringResource(R.string.rules_card_order_title),
                        style = MaterialTheme.typography.titleSmall,
                        color = ImperialGold,
                    )
                    Text(
                        text = stringResource(R.string.rules_card_order_body),
                        style = MaterialTheme.typography.bodyMedium,
                        color = IvoryWhite,
                    )
                }
            }

            Surface(
                color = NavySurfaceElevated,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, NavyBorder),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = stringResource(R.string.rules_payouts_title),
                        style = MaterialTheme.typography.titleSmall,
                        color = ImperialGold,
                    )
                    Text(
                        text = stringResource(R.string.rules_payouts_body),
                        style = MaterialTheme.typography.bodyMedium,
                        color = IvoryWhite,
                    )
                }
            }

            Surface(
                color = NavySurfaceElevated,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, TieEmerald.copy(alpha = 0.45f)),
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shield,
                        contentDescription = null,
                        tint = TieEmerald,
                        modifier = Modifier.size(22.dp),
                    )
                    Text(
                        text = stringResource(R.string.demo_disclaimer_full),
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateMist,
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = onDismiss,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("close_rules_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ImperialGold,
                    contentColor = MidnightNavyDeep,
                ),
                shape = RoundedCornerShape(14.dp),
            ) {
                Text(
                    text = stringResource(R.string.action_close),
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }
    }
}
