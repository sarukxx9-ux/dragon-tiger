package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val DragonTigerColorScheme = darkColorScheme(
    primary = ImperialGold,
    onPrimary = MidnightNavyDeep,
    primaryContainer = NavySurfaceHigh,
    onPrimaryContainer = ImperialGoldBright,
    secondary = DragonCrimson,
    onSecondary = IvoryWhite,
    secondaryContainer = DragonCrimsonSurface,
    onSecondaryContainer = IvoryWhite,
    tertiary = TigerAmber,
    onTertiary = MidnightNavyDeep,
    tertiaryContainer = TigerAmberSurface,
    onTertiaryContainer = IvoryWhite,
    background = MidnightNavy,
    onBackground = IvoryWhite,
    surface = NavySurface,
    onSurface = IvoryWhite,
    surfaceVariant = NavySurfaceElevated,
    onSurfaceVariant = SlateMist,
    outline = NavyBorder,
    outlineVariant = GoldMuted,
    error = DragonCrimson,
    onError = IvoryWhite,
)

private val DragonTigerShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun DragonTigerTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DragonTigerColorScheme,
        typography = DragonTigerTypography,
        shapes = DragonTigerShapes,
        content = content,
    )
}
