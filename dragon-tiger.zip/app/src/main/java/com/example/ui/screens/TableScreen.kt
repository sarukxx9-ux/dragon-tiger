package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.DragonTigerRules
import com.example.domain.PickSide
import com.example.domain.PlayingCard
import com.example.domain.RoundOutcome
import com.example.domain.RoundSettlement
import com.example.ui.DealPhase
import com.example.ui.TableUiState
import com.example.ui.components.BeadRoadStrip
import com.example.ui.components.CasinoChipButton
import com.example.ui.components.FlipPlayingCard
import com.example.ui.components.formatDemoCoins
import com.example.ui.components.formatSignedDemoCoins
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.DragonCrimson
import com.example.ui.theme.DragonCrimsonSurface
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldBright
import com.example.ui.theme.ImperialGoldDark
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MidnightNavyDeep
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavySurfaceHigh
import com.example.ui.theme.SlateMist
import com.example.ui.theme.TieEmerald
import com.example.ui.theme.TieEmeraldSurface
import com.example.ui.theme.TigerAmber
import com.example.ui.theme.TigerAmberSurface

@Composable
fun TableScreen(
    uiState: TableUiState,
    onSelectSide: (PickSide) -> Unit,
    onAddChip: (Long) -> Unit,
    onClearStake: () -> Unit,
    onDoubleStake: () -> Unit,
    onHalveStake: () -> Unit,
    onRebet: () -> Unit,
    onDeal: () -> Unit,
    onClaimRefill: () -> Unit,
    onOpenRules: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val haptics = LocalHapticFeedback.current
    fun triggerHaptic() {
        if (uiState.profile.hapticsEnabled) {
            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MidnightNavyDeep,
                        MidnightNavy,
                        Color(0xFF0A1931),
                        MidnightNavyDeep,
                    )
                )
            ),
    ) {
        // Subtle radial ambient gold & felt pattern
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        ImperialGold.copy(alpha = 0.08f),
                        Color.Transparent,
                    ),
                    center = Offset(size.width * 0.5f, size.height * 0.34f),
                    radius = size.maxDimension * 0.55f,
                ),
                center = Offset(size.width * 0.5f, size.height * 0.34f),
                radius = size.maxDimension * 0.55f,
            )
        }

        BoxWithConstraints(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter,
        ) {
            val isWide = maxWidth >= 600.dp
            val isCompactHeight = maxHeight < 700.dp
            val scrollState = rememberScrollState()

            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = if (isWide) 24.dp else 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                TableTopBar(
                    demoCoins = uiState.profile.demoCoins,
                    needsRefill = uiState.needsRefill,
                    onClaimRefill = {
                        triggerHaptic()
                        onClaimRefill()
                    },
                    onOpenRules = onOpenRules,
                )

                BeadRoadStrip(recentRounds = uiState.recentRounds)

                // Arena: Dragon vs Tiger cards + artwork
                CardBattleArena(
                    dragonCard = uiState.dragonCard,
                    tigerCard = uiState.tigerCard,
                    isDragonRevealed = uiState.isDragonRevealed,
                    isTigerRevealed = uiState.isTigerRevealed,
                    dealPhase = uiState.dealPhase,
                    lastSettlement = uiState.lastSettlement,
                    shoeRemaining = uiState.shoeRemaining,
                    isCompactHeight = isCompactHeight,
                )

                // Result or prompt banner
                TableOutcomeBanner(
                    uiState = uiState,
                )

                // Selection Pads: Dragon | Tie | Tiger
                SelectionZonesRow(
                    selectedSide = uiState.selectedSide,
                    stakeCoins = uiState.stakeCoins,
                    lastSettlement = uiState.lastSettlement,
                    enabled = !uiState.isDealing,
                    onSelectSide = { side ->
                        triggerHaptic()
                        onSelectSide(side)
                    },
                )

                // Quick stake modifiers + Chips
                BettingConsole(
                    stakeCoins = uiState.stakeCoins,
                    demoCoins = uiState.profile.demoCoins,
                    lastStakeCoins = uiState.lastStakeCoins,
                    enabled = !uiState.isDealing,
                    onAddChip = { amount ->
                        triggerHaptic()
                        onAddChip(amount)
                    },
                    onClear = {
                        triggerHaptic()
                        onClearStake()
                    },
                    onHalve = {
                        triggerHaptic()
                        onHalveStake()
                    },
                    onDouble = {
                        triggerHaptic()
                        onDoubleStake()
                    },
                    onRebet = {
                        triggerHaptic()
                        onRebet()
                    },
                )

                // Primary Deal / Refill CTA
                DealActionBar(
                    uiState = uiState,
                    onDeal = {
                        if (uiState.profile.hapticsEnabled) {
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        }
                        onDeal()
                    },
                    onClaimRefill = {
                        triggerHaptic()
                        onClaimRefill()
                    },
                )

                Text(
                    text = stringResource(R.string.demo_disclaimer_short),
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateMist.copy(alpha = 0.72f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun TableTopBar(
    demoCoins: Long,
    needsRefill: Boolean,
    onClaimRefill: () -> Unit,
    onOpenRules: () -> Unit,
) {
    val animatedBalance by animateIntAsState(
        targetValue = demoCoins.coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
        animationSpec = tween(durationMillis = 450),
        label = "demo_coin_counter",
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column {
            Text(
                text = stringResource(R.string.brand_title),
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontFamily = CinzelFontFamily,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.6.sp,
                ),
                color = ImperialGoldBright,
            )
            Text(
                text = stringResource(R.string.brand_subtitle),
                style = MaterialTheme.typography.labelSmall,
                color = SlateMist,
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Surface(
                modifier = Modifier
                    .defaultMinSize(minHeight = 48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .testTag("wallet_pill_button")
                    .clickable(onClick = onClaimRefill),
                color = NavySurfaceElevated,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (needsRefill) TieEmerald else ImperialGold.copy(alpha = 0.75f),
                ),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.MonetizationOn,
                        contentDescription = null,
                        tint = ImperialGoldBright,
                        modifier = Modifier.size(18.dp),
                    )
                    Text(
                        text = formatDemoCoins(animatedBalance.toLong()),
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                        ),
                        color = IvoryWhite,
                    )
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(ImperialGold.copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = stringResource(R.string.cd_refill_coins),
                            tint = ImperialGoldBright,
                            modifier = Modifier.size(14.dp),
                        )
                    }
                }
            }

            Surface(
                color = NavySurfaceElevated,
                shape = CircleShape,
                border = BorderStroke(1.dp, NavyBorder),
            ) {
                IconButton(
                    onClick = onOpenRules,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("rules_button"),
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.HelpOutline,
                        contentDescription = stringResource(R.string.cd_rules_button),
                        tint = ImperialGoldBright,
                    )
                }
            }
        }
    }
}

@Composable
private fun CardBattleArena(
    dragonCard: PlayingCard?,
    tigerCard: PlayingCard?,
    isDragonRevealed: Boolean,
    isTigerRevealed: Boolean,
    dealPhase: DealPhase,
    lastSettlement: RoundSettlement?,
    shoeRemaining: Int,
    isCompactHeight: Boolean,
) {
    val dragonWon = dealPhase == DealPhase.REVEALED && lastSettlement?.winningSide == PickSide.DRAGON
    val tigerWon = dealPhase == DealPhase.REVEALED && lastSettlement?.winningSide == PickSide.TIGER
    val isTie = dealPhase == DealPhase.REVEALED && lastSettlement?.winningSide == PickSide.TIE

    val cardWidth = if (isCompactHeight) 96.dp else 112.dp

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = NavySurface.copy(alpha = 0.92f),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(
            width = 1.2.dp,
            brush = Brush.linearGradient(
                listOf(
                    DragonCrimson.copy(alpha = 0.55f),
                    ImperialGold.copy(alpha = 0.65f),
                    TigerAmber.copy(alpha = 0.55f),
                )
            ),
        ),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 14.dp),
        ) {
            // Subtle shoe counter at top center
            Text(
                text = "6-DECK SHOE • $shoeRemaining",
                style = MaterialTheme.typography.labelSmall,
                color = SlateMist.copy(alpha = 0.65f),
                modifier = Modifier.align(Alignment.TopCenter),
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                // Dragon Side
                FighterCardSlot(
                    title = stringResource(R.string.dragon_label),
                    artworkRes = R.drawable.img_dragon_art,
                    artworkDescription = stringResource(R.string.cd_dragon_artwork),
                    accentColor = DragonCrimson,
                    card = dragonCard,
                    isFaceUp = isDragonRevealed,
                    isWinner = dragonWon || isTie,
                    winnerColor = if (isTie) TieEmerald else DragonCrimson,
                    cardWidth = cardWidth,
                    modifier = Modifier.weight(1f),
                )

                // Center VS Emblem
                Column(
                    modifier = Modifier.padding(horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .graphicsLayer { rotationZ = 45f }
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(listOf(ImperialGoldBright, ImperialGoldDark))
                            )
                            .border(1.5.dp, IvoryWhite.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = stringResource(R.string.vs_label),
                            fontFamily = CinzelFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MidnightNavyDeep,
                            modifier = Modifier.graphicsLayer { rotationZ = -45f },
                        )
                    }
                }

                // Tiger Side
                FighterCardSlot(
                    title = stringResource(R.string.tiger_label),
                    artworkRes = R.drawable.img_tiger_art,
                    artworkDescription = stringResource(R.string.cd_tiger_artwork),
                    accentColor = TigerAmber,
                    card = tigerCard,
                    isFaceUp = isTigerRevealed,
                    isWinner = tigerWon || isTie,
                    winnerColor = if (isTie) TieEmerald else TigerAmber,
                    cardWidth = cardWidth,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun FighterCardSlot(
    title: String,
    artworkRes: Int,
    artworkDescription: String,
    accentColor: Color,
    card: PlayingCard?,
    isFaceUp: Boolean,
    isWinner: Boolean,
    winnerColor: Color,
    cardWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // Side Emblem Header with generated Dragon / Tiger artwork
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Image(
                painter = painterResource(id = artworkRes),
                contentDescription = artworkDescription,
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, accentColor, CircleShape),
                contentScale = ContentScale.Crop,
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontFamily = CinzelFontFamily,
                    letterSpacing = 1.sp,
                ),
                color = if (isWinner) ImperialGoldBright else accentColor,
            )
        }

        // Card container with atmospheric art backdrop
        Box(
            modifier = Modifier
                .width(cardWidth + 24.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(MidnightNavyDeep.copy(alpha = 0.7f))
                .border(
                    width = 1.dp,
                    color = if (isWinner) winnerColor.copy(alpha = 0.9f) else accentColor.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(18.dp),
                )
                .padding(10.dp),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                painter = painterResource(id = artworkRes),
                contentDescription = null,
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(14.dp))
                    .alpha(0.24f),
                contentScale = ContentScale.Crop,
            )

            FlipPlayingCard(
                card = card,
                isFaceUp = isFaceUp,
                isWinner = isWinner,
                winnerGlowColor = winnerColor,
                modifier = Modifier.width(cardWidth),
            )
        }

        // Value readout badge once revealed
        Surface(
            color = if (isFaceUp && card != null) {
                accentColor.copy(alpha = 0.18f)
            } else {
                NavySurfaceElevated
            },
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(
                width = 1.dp,
                color = if (isFaceUp && card != null) accentColor.copy(alpha = 0.7f) else NavyBorder,
            ),
        ) {
            Text(
                text = if (isFaceUp && card != null) {
                    "${card.rank.displayName} (${card.rank.value})"
                } else {
                    "Ready"
                },
                style = MaterialTheme.typography.labelMedium,
                color = if (isFaceUp && card != null) IvoryWhite else SlateMist,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            )
        }
    }
}

@Composable
private fun TableOutcomeBanner(
    uiState: TableUiState,
) {
    val settlement = uiState.lastSettlement
    val bannerText: String
    val bannerColor: Color
    val bannerBg: Color

    when {
        uiState.bannerMessage != null -> {
            bannerText = uiState.bannerMessage
            bannerColor = ImperialGoldBright
            bannerBg = NavySurfaceHigh
        }
        uiState.dealPhase == DealPhase.REVEALED && settlement != null -> {
            val sideTitle = when (settlement.winningSide) {
                PickSide.DRAGON -> stringResource(R.string.result_dragon_wins)
                PickSide.TIGER -> stringResource(R.string.result_tiger_wins)
                PickSide.TIE -> if (settlement.outcome == RoundOutcome.WIN) {
                    stringResource(R.string.result_tie_wins)
                } else {
                    stringResource(R.string.result_tie_half_back)
                }
            }
            val delta = formatSignedDemoCoins(settlement.netCoins)
            bannerText = "$sideTitle  •  $delta Demo Coins"
            bannerColor = when (settlement.outcome) {
                RoundOutcome.WIN -> TieEmerald
                RoundOutcome.HALF_BACK -> ImperialGoldBright
                RoundOutcome.LOSS -> DragonCrimson
            }
            bannerBg = when (settlement.outcome) {
                RoundOutcome.WIN -> TieEmeraldSurface
                RoundOutcome.HALF_BACK -> NavySurfaceHigh
                RoundOutcome.LOSS -> DragonCrimsonSurface
            }
        }
        uiState.isDealing -> {
            bannerText = if (uiState.dealPhase == DealPhase.DEALING_DRAGON) {
                "Revealing Dragon card…"
            } else {
                "Revealing Tiger card…"
            }
            bannerColor = ImperialGoldBright
            bannerBg = NavySurfaceHigh
        }
        else -> {
            bannerText = stringResource(R.string.select_side_prompt)
            bannerColor = SlateMist
            bannerBg = NavySurface
        }
    }

    AnimatedVisibility(
        visible = true,
        enter = fadeIn() + scaleIn(initialScale = 0.96f),
        exit = fadeOut() + scaleOut(),
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("outcome_banner"),
            color = bannerBg,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, bannerColor.copy(alpha = 0.55f)),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                if (settlement != null && settlement.outcome == RoundOutcome.WIN && uiState.dealPhase == DealPhase.REVEALED) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = bannerColor,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text(
                    text = bannerText,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (bannerColor == SlateMist) SlateMist else IvoryWhite,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun SelectionZonesRow(
    selectedSide: PickSide,
    stakeCoins: Long,
    lastSettlement: RoundSettlement?,
    enabled: Boolean,
    onSelectSide: (PickSide) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        PickSideZoneCard(
            side = PickSide.DRAGON,
            title = stringResource(R.string.dragon_label),
            payout = stringResource(R.string.payout_one_to_one),
            accentColor = DragonCrimson,
            surfaceTint = DragonCrimsonSurface,
            artworkRes = R.drawable.img_dragon_art,
            isSelected = selectedSide == PickSide.DRAGON,
            isRoundWinner = lastSettlement?.winningSide == PickSide.DRAGON,
            stakeCoins = if (selectedSide == PickSide.DRAGON) stakeCoins else 0L,
            enabled = enabled,
            onClick = { onSelectSide(PickSide.DRAGON) },
            modifier = Modifier
                .weight(1.15f)
                .testTag("select_dragon_button"),
        )

        PickSideZoneCard(
            side = PickSide.TIE,
            title = stringResource(R.string.tie_label),
            payout = stringResource(R.string.payout_eight_to_one),
            accentColor = TieEmerald,
            surfaceTint = TieEmeraldSurface,
            artworkRes = null,
            isSelected = selectedSide == PickSide.TIE,
            isRoundWinner = lastSettlement?.winningSide == PickSide.TIE,
            stakeCoins = if (selectedSide == PickSide.TIE) stakeCoins else 0L,
            enabled = enabled,
            onClick = { onSelectSide(PickSide.TIE) },
            modifier = Modifier
                .weight(0.88f)
                .testTag("select_tie_button"),
        )

        PickSideZoneCard(
            side = PickSide.TIGER,
            title = stringResource(R.string.tiger_label),
            payout = stringResource(R.string.payout_one_to_one),
            accentColor = TigerAmber,
            surfaceTint = TigerAmberSurface,
            artworkRes = R.drawable.img_tiger_art,
            isSelected = selectedSide == PickSide.TIGER,
            isRoundWinner = lastSettlement?.winningSide == PickSide.TIGER,
            stakeCoins = if (selectedSide == PickSide.TIGER) stakeCoins else 0L,
            enabled = enabled,
            onClick = { onSelectSide(PickSide.TIGER) },
            modifier = Modifier
                .weight(1.15f)
                .testTag("select_tiger_button"),
        )
    }
}

@Composable
private fun PickSideZoneCard(
    side: PickSide,
    title: String,
    payout: String,
    accentColor: Color,
    surfaceTint: Color,
    artworkRes: Int?,
    isSelected: Boolean,
    isRoundWinner: Boolean,
    stakeCoins: Long,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .defaultMinSize(minHeight = 84.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = onClick),
        color = if (isSelected) surfaceTint else NavySurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = if (isSelected || isRoundWinner) 2.dp else 1.dp,
            color = when {
                isRoundWinner -> ImperialGoldBright
                isSelected -> accentColor
                else -> NavyBorder
            },
        ),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
        ) {
            if (artworkRes != null) {
                Image(
                    painter = painterResource(id = artworkRes),
                    contentDescription = null,
                    modifier = Modifier
                        .matchParentSize()
                        .alpha(if (isSelected) 0.16f else 0.06f),
                    contentScale = ContentScale.Crop,
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontFamily = CinzelFontFamily,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                    ),
                    color = if (isSelected) IvoryWhite else accentColor,
                    maxLines = 1,
                )
                Text(
                    text = payout,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isSelected) ImperialGoldBright else SlateMist,
                )
                Surface(
                    color = if (isSelected && stakeCoins > 0L) {
                        ImperialGold.copy(alpha = 0.22f)
                    } else {
                        NavySurfaceElevated.copy(alpha = 0.75f)
                    },
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(
                        1.dp,
                        if (isSelected && stakeCoins > 0L) ImperialGold else NavyBorder,
                    ),
                ) {
                    Text(
                        text = if (stakeCoins > 0L) formatDemoCoins(stakeCoins) else if (side == PickSide.TIE) "8x" else "Pick",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected && stakeCoins > 0L) ImperialGoldBright else SlateMist,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun BettingConsole(
    stakeCoins: Long,
    demoCoins: Long,
    lastStakeCoins: Long,
    enabled: Boolean,
    onAddChip: (Long) -> Unit,
    onClear: () -> Unit,
    onHalve: () -> Unit,
    onDouble: () -> Unit,
    onRebet: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = NavySurface.copy(alpha = 0.92f),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, NavyBorder),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Stake readout + quick modifiers
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column {
                    Text(
                        text = "DEMO STAKE",
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateMist,
                    )
                    Text(
                        text = formatDemoCoins(stakeCoins),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                        ),
                        color = ImperialGoldBright,
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    QuickBetChip(
                        label = stringResource(R.string.action_clear),
                        enabled = enabled && stakeCoins > 0L,
                        onClick = onClear,
                        testTag = "clear_stake_button",
                    )
                    QuickBetChip(
                        label = stringResource(R.string.action_half),
                        enabled = enabled && stakeCoins > DragonTigerRules.MIN_CHIP_DENOMINATION,
                        onClick = onHalve,
                        testTag = "half_stake_button",
                    )
                    QuickBetChip(
                        label = stringResource(R.string.action_double),
                        enabled = enabled && demoCoins > 0L,
                        onClick = onDouble,
                        testTag = "double_stake_button",
                    )
                    QuickBetChip(
                        label = stringResource(R.string.action_rebet),
                        enabled = enabled && lastStakeCoins > 0L && demoCoins >= DragonTigerRules.MIN_CHIP_DENOMINATION,
                        onClick = onRebet,
                        testTag = "rebet_stake_button",
                    )
                }
            }

            // Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                DragonTigerRules.chipDenominations.forEach { amount ->
                    CasinoChipButton(
                        denomination = amount,
                        enabled = enabled && demoCoins >= amount,
                        onClick = { onAddChip(amount) },
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickBetChip(
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    testTag: String,
) {
    Surface(
        modifier = Modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 40.dp)
            .clip(RoundedCornerShape(10.dp))
            .alpha(if (enabled) 1f else 0.4f)
            .testTag(testTag)
            .clickable(enabled = enabled, onClick = onClick),
        color = NavySurfaceElevated,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, NavyBorder),
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = IvoryWhite,
            )
        }
    }
}

@Composable
private fun DealActionBar(
    uiState: TableUiState,
    onDeal: () -> Unit,
    onClaimRefill: () -> Unit,
) {
    if (uiState.needsRefill) {
        Button(
            onClick = onClaimRefill,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("claim_refill_cta"),
            colors = ButtonDefaults.buttonColors(
                containerColor = TieEmerald,
                contentColor = MidnightNavyDeep,
            ),
            shape = RoundedCornerShape(16.dp),
        ) {
            Icon(
                imageVector = Icons.Filled.Refresh,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.action_claim_coins),
                style = MaterialTheme.typography.labelLarge,
            )
        }
    } else {
        val label = when {
            uiState.isDealing -> stringResource(R.string.action_dealing)
            uiState.dealPhase == DealPhase.REVEALED -> stringResource(R.string.action_rebet_deal)
            else -> stringResource(R.string.action_deal)
        }

        Button(
            onClick = onDeal,
            enabled = uiState.canDeal,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("deal_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = ImperialGold,
                contentColor = MidnightNavyDeep,
                disabledContainerColor = NavySurfaceHigh,
                disabledContentColor = SlateMist,
            ),
            shape = RoundedCornerShape(16.dp),
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontFamily = CinzelFontFamily,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.4.sp,
                ),
            )
        }
    }
}
