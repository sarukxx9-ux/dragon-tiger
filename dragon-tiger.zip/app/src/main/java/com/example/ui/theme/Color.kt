package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MidnightNavyDeep = Color(0xFF060E1C)
val MidnightNavy = Color(0xFF091428)
val NavySurface = Color(0xFF10203B)
val NavySurfaceElevated = Color(0xFF15294A)
val NavySurfaceHigh = Color(0xFF1B335C)
val NavyBorder = Color(0xFF284575)

val ImperialGold = Color(0xFFE5B94E)
val ImperialGoldBright = Color(0xFFF7DC88)
val ImperialGoldDark = Color(0xFFB38626)
val GoldMuted = Color(0xFF8B6E32)

val DragonCrimson = Color(0xFFE04556)
val DragonCrimsonSurface = Color(0xFF3A1322)
val TigerAmber = Color(0xFFF09632)
val TigerAmberSurface = Color(0xFF3A2311)
val TieEmerald = Color(0xFF30C997)
val TieEmeraldSurface = Color(0xFF0F352E)

val IvoryWhite = Color(0xFFF8F4EA)
val SlateMist = Color(0xFFA2B3D1)
val MutedSlate = Color(0xFF6B7FA3)

val CardCream = Color(0xFFFCF9F2)
val CardCreamBorder = Color(0xFFD8C9A3)
val CardInkBlack = Color(0xFF131C2E)
val CardInkRed = Color(0xFFC62839)
