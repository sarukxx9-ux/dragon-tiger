package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RoundHistoryEntity
import com.example.domain.PickSide
import com.example.ui.theme.DragonCrimson
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavySurface
import com.example.ui.theme.SlateMist
import com.example.ui.theme.TieEmerald
import com.example.ui.theme.TigerAmber

@Composable
fun BeadRoadStrip(
    recentRounds: List<RoundHistoryEntity>,
    modifier: Modifier = Modifier,
) {
    val latest = recentRounds.take(16)
    val dragonCount = recentRounds.count { it.winningSide == PickSide.DRAGON.name }
    val tigerCount = recentRounds.count { it.winningSide == PickSide.TIGER.name }
    val total = recentRounds.size.coerceAtLeast(1)
    val dragonPct = (dragonCount * 100) / total
    val tigerPct = (tigerCount * 100) / total

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = NavySurface.copy(alpha = 0.85f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, NavyBorder),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            if (latest.isEmpty()) {
                Text(
                    text = "LIVE ROAD  •  Deal first hand to start trend",
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateMist,
                )
            } else {
                LazyRow(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    items(latest, key = { it.id }) { round ->
                        BeadDot(winningSide = round.winningSide)
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "D $dragonPct%",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = DragonCrimson,
                    )
                    Text(
                        text = "T $tigerPct%",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = TigerAmber,
                    )
                }
            }
        }
    }
}

@Composable
fun BeadDot(
    winningSide: String,
    sizeDp: Int = 22,
) {
    val (bg, letter) = when (winningSide) {
        PickSide.DRAGON.name -> DragonCrimson to "D"
        PickSide.TIGER.name -> TigerAmber to "T"
        else -> TieEmerald to "="
    }
    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(CircleShape)
            .background(bg.copy(alpha = 0.22f))
            .border(1.5.dp, bg, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = letter,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = (sizeDp * 0.48f).sp,
            color = IvoryWhite,
        )
    }
}
