package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.PlayingCard
import com.example.domain.Rank
import com.example.ui.theme.CardCream
import com.example.ui.theme.CardCreamBorder
import com.example.ui.theme.CardInkBlack
import com.example.ui.theme.CardInkRed
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldBright
import com.example.ui.theme.MidnightNavyDeep

@Composable
fun FlipPlayingCard(
    card: PlayingCard?,
    isFaceUp: Boolean,
    isWinner: Boolean,
    winnerGlowColor: Color,
    modifier: Modifier = Modifier,
) {
    val rotation by animateFloatAsState(
        targetValue = if (isFaceUp && card != null) 180f else 0f,
        animationSpec = tween(durationMillis = 440, easing = FastOutSlowInEasing),
        label = "card_flip_rotation",
    )

    val winnerScale by animateFloatAsState(
        targetValue = if (isWinner) 1.05f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow,
        ),
        label = "card_winner_scale",
    )

    val density = LocalDensity.current.density
    val shape = RoundedCornerShape(14.dp)

    Box(
        modifier = modifier
            .aspectRatio(0.69f)
            .graphicsLayer {
                scaleX = winnerScale
                scaleY = winnerScale
                rotationY = rotation
                cameraDistance = 14f * density
            }
            .shadow(
                elevation = if (isWinner) 18.dp else 8.dp,
                shape = shape,
                ambientColor = if (isWinner) winnerGlowColor else Color.Black,
                spotColor = if (isWinner) winnerGlowColor else Color.Black,
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (rotation <= 90f || card == null) {
            CardBackFace(
                isHighlighted = isWinner,
                highlightColor = winnerGlowColor,
                shape = shape,
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { rotationY = 180f },
            ) {
                CardFrontFace(
                    card = card,
                    isWinner = isWinner,
                    winnerGlowColor = winnerGlowColor,
                    shape = shape,
                )
            }
        }
    }
}

@Composable
private fun CardBackFace(
    isHighlighted: Boolean,
    highlightColor: Color,
    shape: RoundedCornerShape,
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        shape = shape,
        color = MidnightNavyDeep,
        border = BorderStroke(
            width = if (isHighlighted) 2.dp else 1.5.dp,
            color = if (isHighlighted) highlightColor else ImperialGold.copy(alpha = 0.72f),
        ),
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_card_back),
            contentDescription = stringResource(R.string.cd_card_back),
            modifier = Modifier
                .fillMaxSize()
                .clip(shape),
            contentScale = ContentScale.Crop,
        )
    }
}

@Composable
private fun CardFrontFace(
    card: PlayingCard,
    isWinner: Boolean,
    winnerGlowColor: Color,
    shape: RoundedCornerShape,
) {
    val inkColor = if (card.suit.isRed) CardInkRed else CardInkBlack
    val isCourtOrAce = card.rank == Rank.ACE ||
        card.rank == Rank.JACK ||
        card.rank == Rank.QUEEN ||
        card.rank == Rank.KING

    Surface(
        modifier = Modifier.fillMaxSize(),
        shape = shape,
        color = CardCream,
        border = BorderStroke(
            width = if (isWinner) 2.5.dp else 1.5.dp,
            brush = if (isWinner) {
                Brush.linearGradient(listOf(ImperialGoldBright, winnerGlowColor, ImperialGold))
            } else {
                Brush.linearGradient(listOf(CardCreamBorder, ImperialGold.copy(alpha = 0.55f)))
            },
        ),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            CardCream,
                            Color(0xFFF6EFE0),
                        )
                    )
                )
                .padding(7.dp),
        ) {
            // Subtle inner gold filigree frame
            Canvas(modifier = Modifier.fillMaxSize()) {
                val inset = 3.dp.toPx()
                drawRoundRect(
                    color = ImperialGold.copy(alpha = if (isWinner) 0.55f else 0.28f),
                    topLeft = Offset(inset, inset),
                    size = androidx.compose.ui.geometry.Size(
                        size.width - inset * 2,
                        size.height - inset * 2,
                    ),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(9.dp.toPx()),
                    style = Stroke(width = 1.dp.toPx()),
                )
                if (isCourtOrAce) {
                    drawCircle(
                        color = ImperialGold.copy(alpha = 0.22f),
                        radius = size.minDimension * 0.27f,
                        center = center,
                        style = Stroke(width = 1.2.dp.toPx()),
                    )
                }
            }

            // Top-left corner index
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 5.dp, top = 3.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy((-3).dp),
            ) {
                Text(
                    text = card.rank.symbol,
                    fontFamily = CinzelFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = inkColor,
                )
                Text(
                    text = card.suit.symbol,
                    fontSize = 15.sp,
                    color = inkColor,
                )
            }

            // Center emblem
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = card.suit.symbol,
                    fontSize = if (isCourtOrAce) 40.sp else 36.sp,
                    color = inkColor,
                )
                if (isCourtOrAce) {
                    Text(
                        text = card.rank.displayName.uppercase(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = CinzelFontFamily,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                        ),
                        color = ImperialGoldDarkOrInk(inkColor),
                    )
                }
            }

            // Bottom-right inverted corner index
            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 5.dp, bottom = 3.dp)
                    .graphicsLayer { rotationZ = 180f },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy((-3).dp),
            ) {
                Text(
                    text = card.rank.symbol,
                    fontFamily = CinzelFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = inkColor,
                )
                Text(
                    text = card.suit.symbol,
                    fontSize = 15.sp,
                    color = inkColor,
                )
            }

            if (isWinner) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(8.dp)
                        .border(1.dp, ImperialGoldBright, RoundedCornerShape(50))
                        .background(winnerGlowColor, RoundedCornerShape(50)),
                )
            }
        }
    }
}

private fun ImperialGoldDarkOrInk(inkColor: Color): Color =
    inkColor.copy(alpha = 0.75f)
