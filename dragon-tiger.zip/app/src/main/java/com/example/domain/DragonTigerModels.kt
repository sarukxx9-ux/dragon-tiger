package com.example.domain

enum class Suit(
    val symbol: String,
    val label: String,
    val isRed: Boolean,
) {
    SPADES("♠", "Spades", false),
    HEARTS("♥", "Hearts", true),
    CLUBS("♣", "Clubs", false),
    DIAMONDS("♦", "Diamonds", true),
}

enum class Rank(
    val value: Int,
    val symbol: String,
    val displayName: String,
) {
    ACE(1, "A", "Ace"),
    TWO(2, "2", "2"),
    THREE(3, "3", "3"),
    FOUR(4, "4", "4"),
    FIVE(5, "5", "5"),
    SIX(6, "6", "6"),
    SEVEN(7, "7", "7"),
    EIGHT(8, "8", "8"),
    NINE(9, "9", "9"),
    TEN(10, "10", "10"),
    JACK(11, "J", "Jack"),
    QUEEN(12, "Q", "Queen"),
    KING(13, "K", "King");

    companion object {
        fun fromValue(value: Int): Rank =
            entries.firstOrNull { it.value == value } ?: ACE
    }
}

data class PlayingCard(
    val rank: Rank,
    val suit: Suit,
) {
    val shortLabel: String get() = "${rank.symbol}${suit.symbol}"
}

enum class PickSide(val title: String, val payoutLabel: String) {
    DRAGON("Dragon", "1:1"),
    TIE("Tie", "8:1"),
    TIGER("Tiger", "1:1"),
}

enum class AvatarCrest(
    val id: Int,
    val title: String,
    val subtitle: String,
) {
    DRAGON_GUARDIAN(0, "Azure Dragon", "Imperial Flame"),
    TIGER_SOVEREIGN(1, "Royal Tiger", "Golden Fang"),
    IMPERIAL_LOTUS(2, "Golden Lotus", "Celestial Seal"),
    CROWN_MASTER(3, "Grand Crown", "High Table"),
    ;

    companion object {
        fun fromId(id: Int): AvatarCrest = entries.firstOrNull { it.id == id } ?: DRAGON_GUARDIAN
    }
}

enum class RoundOutcome {
    WIN,
    HALF_BACK,
    LOSS,
}

data class RoundSettlement(
    val dragonCard: PlayingCard,
    val tigerCard: PlayingCard,
    val pickedSide: PickSide,
    val winningSide: PickSide,
    val stakeCoins: Long,
    val payoutCoins: Long,
    val netCoins: Long,
    val outcome: RoundOutcome,
)

class CardShoe(
    private val deckCount: Int = 6,
) {
    private val cards = ArrayDeque<PlayingCard>()

    init {
        reshuffle()
    }

    val remainingCards: Int get() = cards.size

    fun drawPair(): Pair<PlayingCard, PlayingCard> {
        if (cards.size < 16) {
            reshuffle()
        }
        return cards.removeFirst() to cards.removeFirst()
    }

    fun reshuffle() {
        val fresh = buildList {
            repeat(deckCount) {
                for (suit in Suit.entries) {
                    for (rank in Rank.entries) {
                        add(PlayingCard(rank = rank, suit = suit))
                    }
                }
            }
        }.shuffled()
        cards.clear()
        cards.addAll(fresh)
    }
}

object DragonTigerRules {
    const val INITIAL_DEMO_COINS: Long = 10_000L
    const val REFILL_DEMO_COINS: Long = 5_000L
    const val MIN_CHIP_DENOMINATION: Long = 25L

    val chipDenominations: List<Long> = listOf(25L, 100L, 500L, 1_000L, 5_000L)

    fun settleHand(
        dragonCard: PlayingCard,
        tigerCard: PlayingCard,
        pickedSide: PickSide,
        stakeCoins: Long,
    ): RoundSettlement {
        val winningSide = when {
            dragonCard.rank.value > tigerCard.rank.value -> PickSide.DRAGON
            tigerCard.rank.value > dragonCard.rank.value -> PickSide.TIGER
            else -> PickSide.TIE
        }

        val (payoutCoins, outcome) = when {
            pickedSide == winningSide && winningSide == PickSide.TIE ->
                (stakeCoins * 9L) to RoundOutcome.WIN
            pickedSide == winningSide ->
                (stakeCoins * 2L) to RoundOutcome.WIN
            winningSide == PickSide.TIE ->
                (stakeCoins / 2L) to RoundOutcome.HALF_BACK
            else ->
                0L to RoundOutcome.LOSS
        }

        return RoundSettlement(
            dragonCard = dragonCard,
            tigerCard = tigerCard,
            pickedSide = pickedSide,
            winningSide = winningSide,
            stakeCoins = stakeCoins,
            payoutCoins = payoutCoins,
            netCoins = payoutCoins - stakeCoins,
            outcome = outcome,
        )
    }
}
