package com.example.data

import com.example.domain.DragonTigerRules
import com.example.domain.RoundOutcome
import com.example.domain.RoundSettlement
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class DragonTigerRepository(
    private val dao: DragonTigerDao,
) {
    val profileFlow: Flow<PlayerProfileEntity> = dao.observeProfile().map { entity ->
        entity ?: PlayerProfileEntity()
    }

    val recentRoundsFlow: Flow<List<RoundHistoryEntity>> = dao.observeRecentRounds()

    suspend fun ensureInitialized() {
        if (dao.getProfileOnce() == null) {
            dao.upsertProfile(PlayerProfileEntity())
        }
    }

    suspend fun recordRound(settlement: RoundSettlement) {
        val current = dao.getProfileOnce() ?: PlayerProfileEntity()
        val nextRoundNumber = current.totalRounds + 1
        val newBalance = (current.demoCoins - settlement.stakeCoins + settlement.payoutCoins)
            .coerceAtLeast(0L)

        val isWin = settlement.outcome == RoundOutcome.WIN
        val newStreak = if (isWin) current.currentStreak + 1 else 0
        val newBestStreak = maxOf(current.bestStreak, newStreak)
        val newWins = if (isWin) current.totalWins + 1 else current.totalWins
        val newTiesHit = if (isWin && settlement.winningSide.name == "TIE") {
            current.totalTiesHit + 1
        } else {
            current.totalTiesHit
        }
        val newBiggestWin = if (settlement.netCoins > current.biggestWin) {
            settlement.netCoins
        } else {
            current.biggestWin
        }

        dao.upsertProfile(
            current.copy(
                demoCoins = newBalance,
                totalRounds = nextRoundNumber,
                totalWins = newWins,
                totalTiesHit = newTiesHit,
                currentStreak = newStreak,
                bestStreak = newBestStreak,
                biggestWin = newBiggestWin,
            )
        )

        dao.insertRound(
            RoundHistoryEntity(
                roundNumber = nextRoundNumber,
                dragonRank = settlement.dragonCard.rank.value,
                dragonSuit = settlement.dragonCard.suit.name,
                tigerRank = settlement.tigerCard.rank.value,
                tigerSuit = settlement.tigerCard.suit.name,
                pickedSide = settlement.pickedSide.name,
                winningSide = settlement.winningSide.name,
                stakeCoins = settlement.stakeCoins,
                payoutCoins = settlement.payoutCoins,
                netCoins = settlement.netCoins,
            )
        )
    }

    suspend fun claimDemoRefill() {
        val current = dao.getProfileOnce() ?: PlayerProfileEntity()
        dao.upsertProfile(
            current.copy(
                demoCoins = current.demoCoins + DragonTigerRules.REFILL_DEMO_COINS,
                totalRefills = current.totalRefills + 1,
            )
        )
    }

    suspend fun updateDisplayName(name: String) {
        val trimmed = name.trim().take(22)
        if (trimmed.isEmpty()) return
        val current = dao.getProfileOnce() ?: PlayerProfileEntity()
        dao.upsertProfile(current.copy(displayName = trimmed))
    }

    suspend fun updateAvatar(avatarId: Int) {
        val current = dao.getProfileOnce() ?: PlayerProfileEntity()
        dao.upsertProfile(current.copy(avatarId = avatarId))
    }

    suspend fun setHapticsEnabled(enabled: Boolean) {
        val current = dao.getProfileOnce() ?: PlayerProfileEntity()
        dao.upsertProfile(current.copy(hapticsEnabled = enabled))
    }

    suspend fun clearHistory() {
        dao.clearRoundHistory()
    }

    suspend fun resetDemoAccount() {
        val current = dao.getProfileOnce() ?: PlayerProfileEntity()
        dao.clearRoundHistory()
        dao.upsertProfile(
            PlayerProfileEntity(
                displayName = current.displayName,
                avatarId = current.avatarId,
                demoCoins = DragonTigerRules.INITIAL_DEMO_COINS,
                hapticsEnabled = current.hapticsEnabled,
            )
        )
    }
}
