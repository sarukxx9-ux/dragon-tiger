package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.DragonTigerRules

@Entity(tableName = "player_profile")
data class PlayerProfileEntity(
    @PrimaryKey val id: Int = 1,
    val displayName: String = "Imperial Player",
    val avatarId: Int = 0,
    val demoCoins: Long = DragonTigerRules.INITIAL_DEMO_COINS,
    val totalRounds: Int = 0,
    val totalWins: Int = 0,
    val totalTiesHit: Int = 0,
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val biggestWin: Long = 0L,
    val totalRefills: Int = 0,
    val hapticsEnabled: Boolean = true,
)

@Entity(tableName = "round_history")
data class RoundHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val roundNumber: Int,
    val dragonRank: Int,
    val dragonSuit: String,
    val tigerRank: Int,
    val tigerSuit: String,
    val pickedSide: String,
    val winningSide: String,
    val stakeCoins: Long,
    val payoutCoins: Long,
    val netCoins: Long,
    val timestampMillis: Long = System.currentTimeMillis(),
)
