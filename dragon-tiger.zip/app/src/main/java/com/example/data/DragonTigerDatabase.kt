package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [PlayerProfileEntity::class, RoundHistoryEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class DragonTigerDatabase : RoomDatabase() {
    abstract fun dragonTigerDao(): DragonTigerDao

    companion object {
        @Volatile
        private var instance: DragonTigerDatabase? = null

        fun getInstance(context: Context): DragonTigerDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    DragonTigerDatabase::class.java,
                    "dragon_tiger_demo.db",
                ).build().also { instance = it }
            }
        }
    }
}
